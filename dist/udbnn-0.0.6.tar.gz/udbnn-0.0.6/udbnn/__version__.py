"""Current version of package udbnn"""
__version__ = "0.0.6"